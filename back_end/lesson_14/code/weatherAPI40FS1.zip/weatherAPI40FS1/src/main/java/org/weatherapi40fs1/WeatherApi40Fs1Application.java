package org.weatherapi40fs1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WeatherApi40Fs1Application {

    public static void main(String[] args) {
        SpringApplication.run(WeatherApi40Fs1Application.class, args);
    }

}
