package org.weatherapi40fs1.dto;

import lombok.Data;

@Data
public class WeatherDataRequestDto {
    private String latitude;
    private String longitude;
}
