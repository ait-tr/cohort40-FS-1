package org.weatherapi40fs1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WeatherApi40Fs1ApplicationTests {

    @Test
    void contextLoads() {
    }

}
