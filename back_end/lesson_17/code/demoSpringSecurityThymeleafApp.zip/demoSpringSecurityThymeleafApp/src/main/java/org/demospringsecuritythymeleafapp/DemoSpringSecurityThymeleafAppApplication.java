package org.demospringsecuritythymeleafapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoSpringSecurityThymeleafAppApplication {

    public static void main(String[] args) {
        SpringApplication.run(DemoSpringSecurityThymeleafAppApplication.class, args);
    }

}
