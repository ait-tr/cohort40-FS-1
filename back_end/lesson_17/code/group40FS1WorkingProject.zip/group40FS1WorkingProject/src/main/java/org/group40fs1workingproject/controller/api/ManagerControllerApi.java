package org.group40fs1workingproject.controller.api;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.ExampleObject;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import lombok.RequiredArgsConstructor;
import org.group40fs1workingproject.dto.managerDto.ManagerCreateRequestDTO;
import org.group40fs1workingproject.dto.managerDto.ManagerCreateResponseDTO;
import org.group40fs1workingproject.dto.managerDto.ManagerResponseDTO;
import org.group40fs1workingproject.service.ManagerService;
import org.group40fs1workingproject.service.exception.AlreadyExistException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/managers")
public interface ManagerControllerApi {

    @Operation(summary = "Find manager by name")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Found the manager",
                    content = @Content(mediaType = "application/json",
                            schema = @Schema(implementation = ManagerResponseDTO.class))),
            @ApiResponse(responseCode = "404",
                    description = "Manager not found")
    })
    @GetMapping("/{managerName}")
    public ResponseEntity<ManagerResponseDTO> findByManagerName(
            @Parameter(name = "managerName", description = "Name of manager for search", required = true)
            @PathVariable String managerName);

    @Operation(summary = "Create new manager")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "201", description = "Manager created successfully"),
            @ApiResponse(responseCode = "400", description = "Manager already exists",
                    content = @Content(mediaType = "application/json",
                            examples = @ExampleObject(value = "Manager already exists")))
    })
    @PostMapping
    public ResponseEntity<ManagerCreateResponseDTO> createManager(@RequestBody ManagerCreateRequestDTO request) ;

}
