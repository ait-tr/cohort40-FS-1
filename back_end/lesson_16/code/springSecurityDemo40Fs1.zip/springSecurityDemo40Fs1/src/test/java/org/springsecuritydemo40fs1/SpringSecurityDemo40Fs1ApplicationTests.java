package org.springsecuritydemo40fs1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringSecurityDemo40Fs1ApplicationTests {

    @Test
    void contextLoads() {
    }

}
