package org.springsecuritydemo40fs1.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springsecuritydemo40fs1.entity.MyUser;

public interface MyUserRepository extends JpaRepository<MyUser,Integer> {

    MyUser findByLogin(String login);

}
