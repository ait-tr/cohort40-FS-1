package org.springsecuritydemo40fs1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringSecurityDemo40Fs1Application {

    public static void main(String[] args) {
        SpringApplication.run(SpringSecurityDemo40Fs1Application.class, args);
    }

}
