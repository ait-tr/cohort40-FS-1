package org.group40fs1workingproject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Group40Fs1WorkingProjectApplication {

    public static void main(String[] args) {
        SpringApplication.run(Group40Fs1WorkingProjectApplication.class, args);
    }

}
