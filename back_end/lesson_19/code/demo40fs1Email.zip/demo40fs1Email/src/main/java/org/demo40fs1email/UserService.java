package org.demo40fs1email;

import jakarta.mail.MessagingException;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.UUID;

@Service
@RequiredArgsConstructor
public class UserService {
    private final UserRepository repository;
    private final EmailService emailService;

    public void registerUser(String email) throws MessagingException {
//        User user = new User();
//        user.setEmail(email);
//        user.setConfirmationCode(UUID.randomUUID().toString());
//        /*
//        UUID - universal unique identifier
//
//        128-bit
//
//        8-4-4-4-12
//
//        123a4567-e89b-12d3-456789012345
//         */
//
//        user.setConfirmed(false);

        User user = User.builder()
                .email(email)
                .confirmationCode(UUID.randomUUID().toString())
                .confirmed(false)
                .build();

        repository.save(user);

        // тут должна быть отправка confirmationCode на почту

        emailService.sendConfirmationEmailWithHTML(user);
    }

    public boolean confirmUser(String confirmationCode) {
        User user = repository.findByConfirmationCode(confirmationCode);

        if (user != null && !user.isConfirmed()) {
            user.setConfirmed(true);
            repository.save(user);
            return true;
        }

        return false;
    }

}
