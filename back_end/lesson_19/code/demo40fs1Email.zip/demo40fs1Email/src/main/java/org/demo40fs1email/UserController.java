package org.demo40fs1email;

import jakarta.mail.MessagingException;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/users")
public class UserController {
    private final UserService userService;

    @PostMapping("/register")
    public ResponseEntity<String> registerUser(@RequestParam String email) throws MessagingException {
        userService.registerUser(email);
        return ResponseEntity.ok("Registration initiated. Check your email for confirmation code");
    }

    @PostMapping("/confirm")
    public ResponseEntity<String> confirmUser(@RequestParam String confirmationCode){
        if (userService.confirmUser(confirmationCode)) {
            return ResponseEntity.ok("User confirmed successfully");
        } else {
            return ResponseEntity.badRequest().body("Invalid confirmation code");
        }
    }
}
