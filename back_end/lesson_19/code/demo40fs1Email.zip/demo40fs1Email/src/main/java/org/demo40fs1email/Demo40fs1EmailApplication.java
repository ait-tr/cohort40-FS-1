package org.demo40fs1email;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Demo40fs1EmailApplication {

    public static void main(String[] args) {
        SpringApplication.run(Demo40fs1EmailApplication.class, args);
    }

}
