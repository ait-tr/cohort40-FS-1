package org.demo40fs1email;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Demo40fs1EmailApplicationTests {

    @Test
    void contextLoads() {
    }

}
