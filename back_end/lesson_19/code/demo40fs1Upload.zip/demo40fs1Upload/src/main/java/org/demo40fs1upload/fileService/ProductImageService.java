package org.demo40fs1upload.fileService;

import lombok.RequiredArgsConstructor;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.stereotype.Service;

import java.net.MalformedURLException;
import java.nio.file.Path;
import java.nio.file.Paths;

@Service
@RequiredArgsConstructor
public class ProductImageService {

    private final LoadFileFromDirectory lfd;
    public Resource loadProductImage(String filename){
        return lfd.loadFileFromProductDirectory("product_img", filename);
    }


}
