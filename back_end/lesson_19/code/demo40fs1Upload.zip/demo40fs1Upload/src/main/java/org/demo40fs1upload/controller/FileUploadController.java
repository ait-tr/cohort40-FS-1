package org.demo40fs1upload.controller;

import lombok.RequiredArgsConstructor;
import org.demo40fs1upload.fileService.FileStorageService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

@RestController
@RequiredArgsConstructor
public class FileUploadController {

    private final FileStorageService service;

    @PostMapping("/api/upload")
    public ResponseEntity<String> fileUpload(@RequestPart ("file")MultipartFile myFile){
        /*
        multipart/from-data
         */

        try {
            service.storeFile(myFile);
            return ResponseEntity.ok("Файл успешно загружен");
        } catch (Exception e) {
            return ResponseEntity
                    .status(HttpStatus.CONFLICT)
                    .body("Ошибка загрузки файла: {} "+ e.getMessage());
        }
    }
}
