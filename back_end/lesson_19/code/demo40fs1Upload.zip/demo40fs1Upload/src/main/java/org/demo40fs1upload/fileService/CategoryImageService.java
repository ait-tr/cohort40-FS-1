package org.demo40fs1upload.fileService;

import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.stereotype.Service;

import java.net.MalformedURLException;
import java.nio.file.Path;
import java.nio.file.Paths;

@Service
public class CategoryImageService {

    public Resource loadCategoryImage(String filename){
        return loadFileFromCategoryDirectory("category_img", filename);
    }

    private Resource loadFileFromCategoryDirectory(String directory, String filename) {

        try {
            Path filepath = Paths.get("src/main/resources/static/files/" + directory).resolve(filename).normalize();

            Resource resource = new UrlResource(filepath.toUri());

            if (resource.exists() && resource.isReadable()){
                return resource;
            } else {
                throw new RuntimeException("Файл не найден: " + filename);
            }

        } catch (MalformedURLException e) {
            throw new RuntimeException("Ошибка загрузки файла: " + filename);
        }

    }
}
