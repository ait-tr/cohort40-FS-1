package org.demo40fs1upload.controller;

import lombok.RequiredArgsConstructor;
import org.demo40fs1upload.fileService.CategoryImageService;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/category")
public class CategoryImageController {

    private final CategoryImageService service;

    @GetMapping("/image/{filename}")
    public ResponseEntity<Resource> getCategoryImage(@PathVariable String filename){
        Resource image = service.loadCategoryImage(filename);

        // Определяем тип содержимого для изображения

        MediaType mediaType = MediaType.IMAGE_JPEG;

        // необходимо создать заголовок для ответа
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(mediaType);

        // Надо установить заголовок Content - Disposition чтобы браузер понял что это изображение и отобразил его

        headers.setContentDispositionFormData("inline",filename);

        // возвращаем ответ с байтами изображения, заголовками и статусом 200 OK

        return ResponseEntity.ok()
                .headers(headers)
                .body(image);

    }


}
