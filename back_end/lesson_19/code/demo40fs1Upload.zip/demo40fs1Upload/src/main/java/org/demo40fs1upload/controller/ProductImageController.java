package org.demo40fs1upload.controller;

import lombok.RequiredArgsConstructor;
import org.demo40fs1upload.fileService.CategoryImageService;
import org.demo40fs1upload.fileService.ProductImageService;
import org.springframework.core.io.Resource;
import org.springframework.http.ContentDisposition;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.InvalidMimeTypeException;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.io.IOError;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/product")
public class ProductImageController {

    private final ProductImageService service;

    @GetMapping("/image/{filename}")
    public ResponseEntity<Resource> getCategoryImage(@PathVariable String filename) throws IOException {
        Resource image = service.loadProductImage(filename);

        // Определяем тип содержимого для изображения

        MediaType mediaType = MediaType.IMAGE_JPEG;

            String mimeType = Files.probeContentType(Path.of(image.getFile().getAbsolutePath()));
            if (mimeType != null ) {
            mediaType = MediaType.parseMediaType(mimeType);
            }


        // необходимо создать заголовок для ответа
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(mediaType);

        // Надо установить заголовок Content - Disposition чтобы браузер понял что это изображение и отобразил его

        //headers.setContentDispositionFormData("inline",filename);
        headers.setContentDisposition(ContentDisposition.inline().filename(filename).build());

        //headers.setContentDispositionFormData("attachment",filename);

        // возвращаем ответ с байтами изображения, заголовками и статусом 200 OK

        return ResponseEntity.ok()
                .headers(headers)
                .body(image);

    }


}
