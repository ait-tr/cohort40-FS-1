package org.demo40fs1upload;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Demo40fs1UploadApplication {

    public static void main(String[] args) {
        SpringApplication.run(Demo40fs1UploadApplication.class, args);
    }

}
