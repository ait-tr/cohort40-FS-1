package org.demo40fs1upload;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Demo40fs1UploadApplicationTests {

    @Test
    void contextLoads() {
    }

}
