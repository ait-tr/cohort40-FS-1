package org;

import com.google.gson.Gson;

public class AppGson {
    public static void main(String[] args) {
        // создадим объект

        Person person = new Person("John","Smith", 35);

        // преобразовать объект в формат JSON

        Gson gson = new Gson();

        String json = gson.toJson(person);

        System.out.println("JSON: " + json);



    }
}
