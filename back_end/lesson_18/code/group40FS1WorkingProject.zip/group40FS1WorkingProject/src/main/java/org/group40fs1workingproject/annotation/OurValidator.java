package org.group40fs1workingproject.annotation;

import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;

public class OurValidator implements ConstraintValidator<OurValidation,String> {
    @Override
    public void initialize(OurValidation constraintAnnotation) {

    }

    @Override
    public boolean isValid(String string, ConstraintValidatorContext constraintValidatorContext) {
        if (string == null) {
            return true;
        }

        return string.startsWith("S"); // проверка того, что значение начинается с литеры "S"
    }
}
