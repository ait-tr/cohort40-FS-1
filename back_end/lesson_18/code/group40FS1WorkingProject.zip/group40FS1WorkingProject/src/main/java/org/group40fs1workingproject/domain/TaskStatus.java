package org.group40fs1workingproject.domain;

public enum TaskStatus {
    OPEN,
    CLOSE,
    ON_HOLD
}
