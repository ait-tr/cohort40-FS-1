package org.group40fs1workingproject.controller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.group40fs1workingproject.dto.taskDto.TaskCreateOrUpdateResponseDTO;
import org.group40fs1workingproject.dto.taskDto.TaskCreateRequestDTO;
import org.group40fs1workingproject.dto.taskDto.TaskResponseDTO;
import org.group40fs1workingproject.service.TaskService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/tasks")
@RequiredArgsConstructor
public class TaskController {

    private final TaskService taskService;

    @Operation(summary = "Get all tasks")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Found all tasks")
    })
    @GetMapping
    public ResponseEntity<List<TaskResponseDTO>> findAll() {
        return ResponseEntity.ok(taskService.findAll());
    }

    @Operation(summary = "Find task by ID")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Found the task"),
            @ApiResponse(responseCode = "404", description = "Task not found")
    })
    @GetMapping("/{id}")
    public ResponseEntity<TaskResponseDTO> findById(@PathVariable Integer id) {
        return ResponseEntity.ok(taskService.findById(id));
    }

    @Operation(summary = "Find tasks by manager name")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Found tasks for the manager"),
            @ApiResponse(responseCode = "404", description = "Manager not found")
    })
    @GetMapping("/manager/{managerName}")
    public ResponseEntity<List<TaskResponseDTO>> findTasksByManagerName(@PathVariable String managerName) {
        return ResponseEntity.ok(taskService.findTasksByManagerName(managerName));
    }

    @Operation(summary = "Create new task")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "201", description = "Task created successfully"),
            @ApiResponse(responseCode = "404", description = "Manager not found")
    })
    @PostMapping
    public ResponseEntity<TaskCreateOrUpdateResponseDTO> createTask(@Valid @RequestBody TaskCreateRequestDTO request) {
        return ResponseEntity.status(HttpStatus.CREATED).body(taskService.createTask(request));
    }
}
