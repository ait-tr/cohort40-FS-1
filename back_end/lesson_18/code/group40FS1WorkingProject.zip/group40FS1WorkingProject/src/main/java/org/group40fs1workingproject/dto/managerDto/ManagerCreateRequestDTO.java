package org.group40fs1workingproject.dto.managerDto;


import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ManagerCreateRequestDTO {

    @NotNull
    private String managerName;
    @Size(min = 5, max = 15)
    private String password;
    @Email
    private String email;
}
