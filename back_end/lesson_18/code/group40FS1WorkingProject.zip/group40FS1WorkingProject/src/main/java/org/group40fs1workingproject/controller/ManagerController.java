package org.group40fs1workingproject.controller;

import lombok.RequiredArgsConstructor;
import org.group40fs1workingproject.controller.api.ManagerControllerApi;
import org.group40fs1workingproject.dto.managerDto.ManagerCreateRequestDTO;
import org.group40fs1workingproject.dto.managerDto.ManagerCreateResponseDTO;
import org.group40fs1workingproject.dto.managerDto.ManagerResponseDTO;
import org.group40fs1workingproject.service.ManagerService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/managers")
@RequiredArgsConstructor
public class ManagerController implements ManagerControllerApi {

    private final ManagerService managerService;

    @GetMapping("/{managerName}")
    public ResponseEntity<ManagerResponseDTO> findByManagerName( @PathVariable String managerName) {
        return ResponseEntity.ok(managerService.findByManagerName(managerName));
    }

    @PostMapping
    public ResponseEntity<ManagerCreateResponseDTO> createManager(@RequestBody ManagerCreateRequestDTO request) {
        return ResponseEntity.status(HttpStatus.CREATED).body(managerService.createManager(request));
    }

}
